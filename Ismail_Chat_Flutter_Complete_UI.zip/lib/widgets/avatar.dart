
import 'package:flutter/material.dart';

class Avatar extends StatelessWidget {
  final String asset;
  final double size;
  final bool online;
  final VoidCallback? onTap;

  const Avatar({
    super.key,
    required this.asset,
    this.size = 52,
    this.online = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final child = Stack(
      children: [
        ClipOval(
          child: Image.asset(
            'assets/$asset',
            width: size,
            height: size,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => CircleAvatar(
              radius: size / 2,
              child: const Icon(Icons.person),
            ),
          ),
        ),
        if (online)
          Positioned(
            right: 1,
            bottom: 1,
            child: Container(
              width: size * .24,
              height: size * .24,
              decoration: BoxDecoration(
                color: const Color(0xFF18C98B),
                shape: BoxShape.circle,
                border: Border.all(
                  color: Theme.of(context).scaffoldBackgroundColor,
                  width: 2,
                ),
              ),
            ),
          ),
      ],
    );
    return onTap == null ? child : GestureDetector(onTap: onTap, child: child);
  }
}
