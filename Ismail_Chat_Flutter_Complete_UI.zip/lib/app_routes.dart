
import 'package:flutter/material.dart';
import 'screens/onboarding_screen.dart';
import 'screens/login_screen.dart';
import 'screens/otp_screen.dart';
import 'screens/profile_setup_screen.dart';
import 'screens/home_shell.dart';
import 'screens/chat_screen.dart';
import 'screens/contact_profile_screen.dart';
import 'screens/group_chat_screen.dart';
import 'screens/notifications_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/message_info_screen.dart';
import 'screens/media_gallery_screen.dart';

class AppRoutes {
  static Route<dynamic> generate(RouteSettings settings) {
    switch (settings.name) {
      case '/onboarding':
        return _fade(const OnboardingScreen());
      case '/login':
        return _fade(const LoginScreen());
      case '/otp':
        return _fade(const OtpScreen());
      case '/profile':
        return _fade(const ProfileSetupScreen());
      case '/home':
        return _fade(const HomeShell());
      case '/chat':
        return _slide(const ChatScreen());
      case '/group':
        return _slide(const GroupChatScreen());
      case '/contact':
        return _slide(const ContactProfileScreen());
      case '/notifications':
        return _slide(const NotificationsScreen());
      case '/settings':
        return _slide(const SettingsScreen());
      case '/message-info':
        return _slide(const MessageInfoScreen());
      case '/gallery':
        return _slide(const MediaGalleryScreen());
      default:
        return _fade(const HomeShell());
    }
  }

  static PageRouteBuilder _fade(Widget child) => PageRouteBuilder(
        pageBuilder: (_, __, ___) => child,
        transitionsBuilder: (_, a, __, child) =>
            FadeTransition(opacity: a, child: child),
      );

  static PageRouteBuilder _slide(Widget child) => PageRouteBuilder(
        pageBuilder: (_, __, ___) => child,
        transitionsBuilder: (_, a, __, child) => SlideTransition(
          position: Tween(begin: const Offset(1, 0), end: Offset.zero)
              .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
          child: child,
        ),
      );
}
