
import 'package:flutter/material.dart';
import '../widgets/avatar.dart';

class ContactProfileScreen extends StatefulWidget {
  const ContactProfileScreen({super.key});
  @override State<ContactProfileScreen> createState() => _ContactProfileScreenState();
}
class _ContactProfileScreenState extends State<ContactProfileScreen> {
  bool onlineAlert = true;
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: BackButton(), title: const Text('Contact info', style: TextStyle(fontWeight: FontWeight.w800))),
    body: ListView(children: [
      const SizedBox(height: 20),
      const Center(child: Avatar(asset: 'avatar_female.png', size: 120, online: true)),
      const SizedBox(height: 14),
      const Center(child: Text('Ananya', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900))),
      const Center(child: Text('online', style: TextStyle(color: Color(0xFF0BAA72), fontWeight: FontWeight.w700))),
      const SizedBox(height: 18),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        _roundAction(Icons.message_outlined, 'Message'),
        _roundAction(Icons.call_outlined, 'Call'),
        _roundAction(Icons.videocam_outlined, 'Video'),
        _roundAction(Icons.search, 'Search'),
      ]),
      const SizedBox(height: 20),
      const Divider(),
      ListTile(title: const Text('About'), subtitle: const Text("Hey! I'm using Ismail 😊")),
      const Divider(),
      ListTile(title: const Text('Media, links and docs'), subtitle: const Text('825'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.pushNamed(context, '/gallery')),
      ListTile(title: const Text('Starred messages'), trailing: const Icon(Icons.chevron_right)),
      const Divider(),
      SwitchListTile(
        value: onlineAlert,
        onChanged: (v) => setState(() => onlineAlert = v),
        secondary: const Icon(Icons.notifications_active_outlined),
        title: const Text('Online/offline notifications'),
        subtitle: const Text('Notify me when Ananya comes online or goes offline'),
      ),
      const ListTile(leading: Icon(Icons.timer_outlined), title: Text('Disappearing messages'), subtitle: Text('Off')),
      const ListTile(leading: Icon(Icons.lock_outline), title: Text('Encryption'), subtitle: Text('Messages are end-to-end encrypted')),
      const Divider(),
      ListTile(leading: const Icon(Icons.block, color: Colors.red), title: const Text('Block Ananya', style: TextStyle(color: Colors.red))),
      ListTile(leading: const Icon(Icons.report_gmailerrorred, color: Colors.red), title: const Text('Report Ananya', style: TextStyle(color: Colors.red))),
    ]),
  );

  Widget _roundAction(IconData icon, String text) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 8),
    child: Column(children: [
      CircleAvatar(backgroundColor: const Color(0xFFE3F8EF), child: Icon(icon, color: const Color(0xFF0BAA72))),
      const SizedBox(height: 6), Text(text, style: const TextStyle(fontSize: 12)),
    ]),
  );
}
