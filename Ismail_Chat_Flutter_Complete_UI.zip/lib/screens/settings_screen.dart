
import 'package:flutter/material.dart';
import '../widgets/avatar.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}
class _SettingsScreenState extends State<SettingsScreen> {
  bool notifications = true, onlineAlerts = true, readReceipts = true, dark = false;
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: const BackButton(), title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.w800))),
    body: ListView(children: [
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        leading: const Avatar(asset: 'avatar_female.png', size: 58),
        title: const Text('Ananya', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        subtitle: const Text('+91 98765 43210'),
        trailing: const Icon(Icons.chevron_right),
      ),
      const Divider(),
      _group('Account', [
        _tile(Icons.lock_outline, 'Privacy', 'Last seen, profile photo, read receipts'),
        _tile(Icons.key_outlined, 'Security', 'Security notifications'),
        _tile(Icons.verified_user_outlined, 'Two-step verification', 'Add extra protection'),
        _tile(Icons.phone_android_outlined, 'Change number', 'Move your account to a new number'),
      ]),
      _group('Chats', [
        _tile(Icons.chat_bubble_outline, 'Chats', 'Theme, wallpapers, chat history'),
        SwitchListTile(value: readReceipts, onChanged: (v) => setState(() => readReceipts = v), secondary: const Icon(Icons.done_all), title: const Text('Read receipts')),
      ]),
      _group('Notifications', [
        SwitchListTile(value: notifications, onChanged: (v) => setState(() => notifications = v), secondary: const Icon(Icons.notifications_none), title: const Text('Message notifications')),
        SwitchListTile(value: onlineAlerts, onChanged: (v) => setState(() => onlineAlerts = v), secondary: const Icon(Icons.circle, color: Color(0xFF0BAA72)), title: const Text('Online/offline alerts')),
      ]),
      _group('Appearance', [
        SwitchListTile(value: dark, onChanged: (v) => setState(() => dark = v), secondary: const Icon(Icons.dark_mode_outlined), title: const Text('Dark mode')),
      ]),
      _group('Storage and data', [
        _tile(Icons.data_usage_outlined, 'Storage and data', 'Network usage, auto-download'),
      ]),
      _group('Other', [
        _tile(Icons.help_outline, 'Help', 'Help center, contact us'),
        _tile(Icons.group_add_outlined, 'Invite a friend', 'Share Ismail'),
        _tile(Icons.info_outline, 'About Ismail', 'v1.0.0'),
      ]),
    ]),
  );

  Widget _group(String title, List<Widget> children) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Padding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 6), child: Text(title.toUpperCase(), style: const TextStyle(color: Color(0xFF0BAA72), fontWeight: FontWeight.w900, fontSize: 12))),
    ...children,
  ]);

  Widget _tile(IconData icon, String title, String sub) => ListTile(
    leading: Icon(icon), title: Text(title), subtitle: Text(sub), trailing: const Icon(Icons.chevron_right, size: 20),
  );
}
