
import 'package:flutter/material.dart';
import '../widgets/avatar.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override Widget build(BuildContext context) => SafeArea(
    child: ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 30), children: [
      const Text('Profile', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 22),
      Center(child: Stack(children: [
        const Avatar(asset: 'avatar_female.png', size: 112),
        Positioned(right: 0, bottom: 0, child: CircleAvatar(
          radius: 20, backgroundColor: const Color(0xFF0BAA72),
          child: IconButton(onPressed: () {}, icon: const Icon(Icons.edit, color: Colors.white, size: 18)),
        )),
      ])),
      const SizedBox(height: 14),
      const Center(child: Text('Ananya', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
      Center(child: Text('+91 98765 43210', style: TextStyle(color: Colors.grey.shade600))),
      const SizedBox(height: 22),
      Card(child: Column(children: [
        ListTile(leading: const Icon(Icons.qr_code_2), title: const Text('QR code'), subtitle: const Text('Share your Ismail profile')),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.notifications_none), title: const Text('Notifications'), onTap: () => Navigator.pushNamed(context, '/notifications')),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('Settings'), onTap: () => Navigator.pushNamed(context, '/settings')),
      ])),
      const SizedBox(height: 14),
      OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.share_outlined), label: const Text('Invite a friend')),
    ]),
  );
}
