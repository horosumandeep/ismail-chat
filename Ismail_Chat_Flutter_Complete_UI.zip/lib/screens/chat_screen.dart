
import 'package:flutter/material.dart';
import '../widgets/avatar.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override State<ChatScreen> createState() => _ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  final messages = <Map<String, dynamic>>[
    {'text': 'Hi 👋', 'me': false, 'time': '10:20 AM'},
    {'text': 'Hello! How are you?', 'me': true, 'time': '10:21 AM'},
    {'text': "I'm good 😊 What about you?", 'me': false, 'time': '10:22 AM'},
    {'text': 'Doing great ❤️', 'me': true, 'time': '10:23 AM'},
    {'text': 'This is a photo', 'me': true, 'time': '10:24 AM', 'photo': true},
  ];

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)),
      titleSpacing: 0,
      title: Row(children: [
        const Avatar(asset: 'avatar_female.png', size: 42, online: true),
        const SizedBox(width: 10),
        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Ananya', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          Text('online', style: TextStyle(fontSize: 11, color: Color(0xFF0BAA72))),
        ]),
      ]),
      actions: [
        IconButton(onPressed: () {}, icon: const Icon(Icons.videocam_outlined)),
        IconButton(onPressed: () {}, icon: const Icon(Icons.call_outlined)),
        IconButton(onPressed: () => Navigator.pushNamed(context, '/contact'), icon: const Icon(Icons.more_vert)),
      ],
    ),
    body: Column(children: [
      Expanded(child: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(image: AssetImage('assets/chat_bg.png'), fit: BoxFit.cover, opacity: .30),
        ),
        child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(12, 18, 12, 18),
          itemCount: messages.length,
          itemBuilder: (_, i) => _bubble(messages[i]),
        ),
      )),
      _composer(),
    ]),
  );

  Widget _bubble(Map<String, dynamic> m) {
    final me = m['me'] as bool;
    return Align(
      alignment: me ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _messageMenu(context),
        onDoubleTap: () => setState(() => m['reaction'] = '❤️'),
        child: Container(
          constraints: const BoxConstraints(maxWidth: 320),
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.fromLTRB(12, 9, 10, 7),
          decoration: BoxDecoration(
            color: me ? const Color(0xFFD5F9E9) : Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(17), topRight: const Radius.circular(17),
              bottomLeft: Radius.circular(me ? 17 : 4), bottomRight: Radius.circular(me ? 4 : 17),
            ),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 8)],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            if (m['photo'] == true)
              ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset('assets/profile_default.png', width: 250, height: 180, fit: BoxFit.cover)),
            if (m['photo'] == true) const SizedBox(height: 5),
            Align(alignment: Alignment.centerLeft, child: Text(m['text'], style: const TextStyle(fontSize: 15))),
            const SizedBox(height: 2),
            Row(mainAxisSize: MainAxisSize.min, children: [
              Text(m['time'], style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
              if (me) ...[const SizedBox(width: 4), const Icon(Icons.done_all, size: 15, color: Color(0xFF168BDB))],
            ]),
            if (m['reaction'] != null) const Text('❤️', style: TextStyle(fontSize: 14)),
          ]),
        ),
      ),
    );
  }

  Widget _composer() => SafeArea(child: Padding(
    padding: const EdgeInsets.fromLTRB(8, 7, 8, 8),
    child: Row(children: [
      Expanded(child: TextField(
        controller: controller,
        minLines: 1, maxLines: 4,
        decoration: InputDecoration(
          hintText: 'Message...',
          prefixIcon: IconButton(onPressed: () => _sendSheet(context), icon: const Icon(Icons.emoji_emotions_outlined)),
          suffixIcon: IconButton(onPressed: () => _sendSheet(context), icon: const Icon(Icons.attach_file)),
          filled: true, fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
        ),
      )),
      const SizedBox(width: 7),
      CircleAvatar(
        radius: 25, backgroundColor: const Color(0xFF0BAA72),
        child: IconButton(
          onPressed: () {
            if (controller.text.trim().isNotEmpty) {
              setState(() { messages.add({'text': controller.text.trim(), 'me': true, 'time': 'Now'}); controller.clear(); });
            } else {
              _sendSheet(context);
            }
          },
          icon: Icon(controller.text.trim().isEmpty ? Icons.mic : Icons.send, color: Colors.white),
        ),
      ),
    ]),
  ));

  void _sendSheet(BuildContext context) => showModalBottomSheet(
    context: context, showDragHandle: true,
    builder: (_) => SafeArea(child: Padding(
      padding: const EdgeInsets.all(20),
      child: GridView.count(shrinkWrap: true, crossAxisCount: 4, children: [
        _option(Icons.image_outlined, 'Gallery'),
        _option(Icons.camera_alt_outlined, 'Camera'),
        _option(Icons.videocam_outlined, 'Video'),
        _option(Icons.mic_none, 'Audio'),
        _option(Icons.location_on_outlined, 'Location'),
        _option(Icons.person_outline, 'Contact'),
        _option(Icons.insert_drive_file_outlined, 'Document'),
        _option(Icons.poll_outlined, 'Poll'),
      ]),
    )),
  );

  Widget _option(IconData icon, String label) => InkWell(
    onTap: () => Navigator.pop(context),
    child: Column(children: [
      CircleAvatar(radius: 27, backgroundColor: const Color(0xFFE3F8EF), child: Icon(icon, color: const Color(0xFF0BAA72))),
      const SizedBox(height: 6),
      Text(label, style: const TextStyle(fontSize: 12)),
    ]),
  );

  void _messageMenu(BuildContext context) => showModalBottomSheet(
    context: context, showDragHandle: true,
    builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
      ListTile(leading: const Icon(Icons.reply), title: const Text('Reply'), onTap: () => Navigator.pop(context)),
      ListTile(leading: const Icon(Icons.forward), title: const Text('Forward'), onTap: () => Navigator.pop(context)),
      ListTile(leading: const Icon(Icons.star_border), title: const Text('Star'), onTap: () => Navigator.pop(context)),
      ListTile(leading: const Icon(Icons.info_outline), title: const Text('Info'), onTap: () { Navigator.pop(context); Navigator.pushNamed(context, '/message-info'); }),
      ListTile(leading: const Icon(Icons.delete_outline, color: Colors.red), title: const Text('Delete', style: TextStyle(color: Colors.red)), onTap: () => Navigator.pop(context)),
    ])),
  );
}
