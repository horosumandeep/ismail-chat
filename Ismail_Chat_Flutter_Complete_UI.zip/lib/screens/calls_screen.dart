
import 'package:flutter/material.dart';
import '../widgets/avatar.dart';

class CallsScreen extends StatelessWidget {
  const CallsScreen({super.key});
  @override Widget build(BuildContext context) => SafeArea(
    child: ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 20), children: [
      Row(children: [
        const Text('Calls', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const Spacer(),
        IconButton(onPressed: () {}, icon: const Icon(Icons.add_call)),
      ]),
      const SizedBox(height: 12),
      Card(child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFE0F7EF), child: Icon(Icons.link, color: Color(0xFF0BAA72))),
        title: const Text('Create call link', style: TextStyle(fontWeight: FontWeight.w800)),
        subtitle: const Text('Share a link for your Ismail call'),
      )),
      const SizedBox(height: 18),
      ...[
        ('Ananya', 'avatar_female.png', 'Outgoing • Today, 10:30 AM', Icons.call_made),
        ('Rahul', 'avatar_male.png', 'Incoming • Today, 09:10 AM', Icons.call_received),
        ('Mom', 'contact_2.png', 'Missed • Yesterday', Icons.call_missed),
        ('Aarav', 'contact_1.png', 'Incoming • 11/09/25', Icons.call_received),
      ].map((x) => ListTile(
        leading: Avatar(asset: x.$2, size: 52),
        title: Text(x.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Row(children: [Icon(x.$4, size: 15, color: x.$4 == Icons.call_missed ? Colors.red : const Color(0xFF0BAA72)), const SizedBox(width: 5), Text(x.$3)]),
        trailing: IconButton(onPressed: () {}, icon: const Icon(Icons.call_outlined)),
      )),
    ]),
  );
}
