
import 'package:flutter/material.dart';

class MessageInfoScreen extends StatelessWidget {
  const MessageInfoScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: const BackButton(), title: const Text('Message info', style: TextStyle(fontWeight: FontWeight.w800))),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Align(alignment: Alignment.centerRight, child: Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: const Color(0xFFD5F9E9), borderRadius: BorderRadius.circular(16)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('Hello! How are you?', style: TextStyle(fontSize: 16)),
          SizedBox(height: 4), Text('10:21 AM', style: TextStyle(fontSize: 10)),
        ]),
      )),
      const SizedBox(height: 28),
      const Text('Read', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
      const SizedBox(height: 8),
      const ListTile(leading: Icon(Icons.done_all, color: Colors.blue), title: Text('Ananya'), subtitle: Text('10:22 AM')),
      const Divider(),
      const Text('Delivered', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
      const SizedBox(height: 8),
      const ListTile(leading: Icon(Icons.done_all, color: Colors.grey), title: Text('Ananya'), subtitle: Text('10:21 AM')),
      const Divider(),
      const Text('Sent', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
      const SizedBox(height: 8),
      const ListTile(leading: Icon(Icons.done, color: Colors.grey), title: Text('Ananya'), subtitle: Text('10:21 AM')),
    ]),
  );
}
