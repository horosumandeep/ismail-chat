
import 'package:flutter/material.dart';
import '../widgets/avatar.dart';

class UpdatesScreen extends StatelessWidget {
  const UpdatesScreen({super.key});
  @override Widget build(BuildContext context) => SafeArea(
    child: ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 20), children: [
      const Text('Updates', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 18),
      Card(child: ListTile(
        leading: Stack(children: [
          const Avatar(asset: 'avatar_female.png', size: 58),
          Positioned(right: 0, bottom: 0, child: Container(
            width: 22, height: 22, decoration: const BoxDecoration(color: Color(0xFF0BAA72), shape: BoxShape.circle),
            child: const Icon(Icons.add, color: Colors.white, size: 16),
          )),
        ]),
        title: const Text('My status', style: TextStyle(fontWeight: FontWeight.w800)),
        subtitle: const Text('Tap to add status update'),
        onTap: () {},
      )),
      const SizedBox(height: 22),
      const Text('Recent updates', style: TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      ...[
        ('Ananya', 'avatar_female.png', '2 minutes ago'),
        ('Rahul', 'avatar_male.png', '10 minutes ago'),
        ('Priya', 'contact_2.png', '30 minutes ago'),
        ('Aarav', 'contact_1.png', '1 hour ago'),
        ('Mom', 'contact_2.png', '2 hours ago'),
      ].map((x) => ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Container(
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xFF0BAA72), width: 2)),
          child: Avatar(asset: x.$2, size: 50),
        ),
        title: Text(x.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(x.$3),
      )),
    ]),
  );
}
