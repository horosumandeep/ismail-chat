
import 'package:flutter/material.dart';

class ProfileSetupScreen extends StatelessWidget {
  const ProfileSetupScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Profile setup', style: TextStyle(fontWeight: FontWeight.w800))),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(24), children: [
      Center(child: Stack(children: [
        CircleAvatar(radius: 64, backgroundImage: AssetImage('assets/avatar_female.png')),
        Positioned(right: 0, bottom: 0, child: CircleAvatar(
          radius: 21, backgroundColor: const Color(0xFF0BAA72),
          child: IconButton(onPressed: () {}, icon: const Icon(Icons.camera_alt, color: Colors.white, size: 19)),
        )),
      ])),
      const SizedBox(height: 28),
      const TextField(decoration: InputDecoration(labelText: 'Your name', border: OutlineInputBorder())),
      const SizedBox(height: 16),
      const TextField(maxLines: 3, decoration: InputDecoration(
        labelText: 'About (optional)', border: OutlineInputBorder(), hintText: "Hey! I'm using Ismail 😊")),
      const SizedBox(height: 26),
      SizedBox(height: 54, child: FilledButton(
        onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
        child: const Text('Continue'),
      )),
    ])),
  );
}
