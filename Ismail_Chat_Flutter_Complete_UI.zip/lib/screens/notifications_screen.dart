
import 'package:flutter/material.dart';
import '../widgets/avatar.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: const BackButton(), title: const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w800))),
    body: ListView(padding: const EdgeInsets.all(12), children: [
      Padding(padding: const EdgeInsets.fromLTRB(8, 8, 8, 14), child: Wrap(spacing: 8, children: [
        FilterChip(label: const Text('All'), selected: true, onSelected: (_) {}),
        FilterChip(label: const Text('Messages'), selected: false, onSelected: (_) {}),
        FilterChip(label: const Text('System'), selected: false, onSelected: (_) {}),
      ])),
      _item('Ananya is online 🟢', 'Just now', 'avatar_female.png', true),
      _item('Ananya is offline ⚪', '2 minutes ago', 'avatar_female.png', false),
      _item('Rahul is online 🟢', '10 minutes ago', 'avatar_male.png', true),
      _item('Rahul is offline ⚪', '20 minutes ago', 'avatar_male.png', false),
      _item('New message from Priya', 'Hey! Are you coming?', 'contact_2.png', false),
      _item('Group call ended', 'Best Friends • 2 hours ago', 'group_avatar.png', false),
    ]),
  );

  Widget _item(String title, String sub, String avatar, bool online) => Card(
    margin: const EdgeInsets.only(bottom: 8),
    child: ListTile(
      leading: Stack(children: [Avatar(asset: avatar, size: 50), if (online) Positioned(right: 0, bottom: 0, child: Container(width: 14, height: 14, decoration: BoxDecoration(color: const Color(0xFF0BAA72), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))]),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(sub),
      trailing: const Icon(Icons.chevron_right),
    ),
  );
}
