
import 'package:flutter/material.dart';
import '../widgets/avatar.dart';
import '../widgets/section_title.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  final chats = [
    ('Ananya', 'avatar_female.png', 'Hey! How are you?', '10:30 AM', 2, true),
    ('Rahul', 'avatar_male.png', '📷 Photo', '09:15 AM', 1, true),
    ('Best Friends', 'group_avatar.png', 'Priya: 😊❤️', 'Yesterday', 0, false),
    ('Office Group', 'contact_3.png', 'You: Meeting at 5 PM', 'Yesterday', 0, false),
    ('Mom', 'contact_2.png', 'Voice call', '12/09/25', 0, false),
    ('Aarav', 'contact_1.png', '📍 Location', '11/09/25', 0, false),
  ];

  @override
  Widget build(BuildContext context) => SafeArea(
    child: CustomScrollView(slivers: [
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 14, 4),
        child: Row(children: [
          Row(children: [
            Image.asset('assets/app_logo.png', width: 36, height: 36),
            const SizedBox(width: 10),
            const Text('Ismail', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          ]),
          const Spacer(),
          IconButton(onPressed: () {}, icon: const Icon(Icons.camera_alt_outlined)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          IconButton(onPressed: () => Navigator.pushNamed(context, '/notifications'), icon: const Icon(Icons.notifications_none)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert)),
        ]),
      )),
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 8),
        child: TextField(
          decoration: InputDecoration(
            hintText: 'Search chats',
            prefixIcon: const Icon(Icons.search),
            filled: true, fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
          ),
        ),
      )),
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
        child: Row(children: [
          ChoiceChip(label: const Text('All'), selected: true, onSelected: (_) {}),
          const SizedBox(width: 8),
          ChoiceChip(label: const Text('Unread'), selected: false, onSelected: (_) {}),
          const SizedBox(width: 8),
          ChoiceChip(label: const Text('Groups'), selected: false, onSelected: (_) {}),
        ]),
      )),
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 4),
        child: SectionTitle('Chats', action: 'Edit'),
      )),
      SliverList.builder(
        itemCount: chats.length,
        itemBuilder: (_, i) {
          final c = chats[i];
          return ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
            leading: Avatar(asset: c.$2, size: 54, online: c.$6),
            title: Row(children: [
              Expanded(child: Text(c.$1, style: const TextStyle(fontWeight: FontWeight.w800))),
              Text(c.$4, style: TextStyle(fontSize: 11, color: c.$5 > 0 ? const Color(0xFF0BAA72) : Colors.grey)),
            ]),
            subtitle: Row(children: [
              Expanded(child: Text(c.$3, maxLines: 1, overflow: TextOverflow.ellipsis)),
              if (c.$5 > 0) Container(
                width: 21, height: 21, alignment: Alignment.center,
                decoration: const BoxDecoration(color: Color(0xFF0BAA72), shape: BoxShape.circle),
                child: Text('${c.$5}', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
              ),
            ]),
            onTap: () => Navigator.pushNamed(context, c.$1 == 'Best Friends' ? '/group' : '/chat'),
            onLongPress: () => _showChatMenu(context, c.$1),
          );
        },
      ),
    ]),
  );

  void _showChatMenu(BuildContext context, String name) {
    showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.push_pin_outlined), title: const Text('Pin chat'), onTap: () => Navigator.pop(context)),
        ListTile(leading: const Icon(Icons.notifications_off_outlined), title: const Text('Mute notifications'), onTap: () => Navigator.pop(context)),
        ListTile(leading: const Icon(Icons.archive_outlined), title: const Text('Archive'), onTap: () => Navigator.pop(context)),
        ListTile(leading: const Icon(Icons.delete_outline, color: Colors.red), title: const Text('Delete', style: TextStyle(color: Colors.red)), onTap: () => Navigator.pop(context)),
      ]),
    ));
  }
}
