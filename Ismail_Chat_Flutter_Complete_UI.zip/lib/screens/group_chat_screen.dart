
import 'package:flutter/material.dart';
import '../widgets/avatar.dart';

class GroupChatScreen extends StatelessWidget {
  const GroupChatScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: BackButton(),
      title: Row(children: [
        const Avatar(asset: 'group_avatar.png', size: 40),
        const SizedBox(width: 10),
        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Best Friends', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          Text('12 members', style: TextStyle(fontSize: 11)),
        ]),
      ]),
      actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.videocam_outlined)), IconButton(onPressed: () {}, icon: const Icon(Icons.call_outlined))],
    ),
    body: Column(children: [
      Expanded(child: ListView(padding: const EdgeInsets.all(12), children: [
        _msg('Priya', 'Hey guys! 👋', '10:10 AM', false, 'contact_2.png'),
        _msg('Rahul', "Let's plan a trip", '10:12 AM', false, 'avatar_male.png'),
        _msg('You', 'Sure! Which place?', '10:12 AM', true, 'avatar_female.png'),
        _msg('Priya', 'What about the mountains? 🏔️', '10:15 AM', false, 'contact_2.png'),
        Align(alignment: Alignment.centerRight, child: Container(
          margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: const Color(0xFFD5F9E9), borderRadius: BorderRadius.circular(15)),
          child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset('assets/media_illustration.png', width: 210, height: 140, fit: BoxFit.cover)),
        )),
      ])),
      SafeArea(child: Padding(
        padding: const EdgeInsets.all(8),
        child: TextField(decoration: InputDecoration(
          hintText: 'Message...',
          prefixIcon: const Icon(Icons.emoji_emotions_outlined),
          suffixIcon: IconButton(onPressed: () {}, icon: const Icon(Icons.mic)),
          filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
        )),
      )),
    ]),
  );

  Widget _msg(String name, String text, String time, bool me, String avatarAsset) => Align(
    alignment: me ? Alignment.centerRight : Alignment.centerLeft,
    child: Container(
      constraints: const BoxConstraints(maxWidth: 310),
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: me ? const Color(0xFFD5F9E9) : Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (!me) ...[Avatar(asset: avatarAsset, size: 28), const SizedBox(width: 7)],
        Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (!me) Text(name, style: const TextStyle(fontSize: 11, color: Color(0xFF0BAA72), fontWeight: FontWeight.w800)),
          Text(text), const SizedBox(height: 2), Text(time, style: TextStyle(fontSize: 9, color: Colors.grey.shade600)),
        ])),
      ]),
    ),
  );
}
