
import 'package:flutter/material.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override State<OnboardingScreen> createState() => _OnboardingScreenState();
}
class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController controller = PageController();
  int page = 0;
  final data = [
    ('Stay Connected', 'Fast, simple and private messaging with Ismail.', 'onboarding_1.png'),
    ('Share Everything', 'Photos, videos, files, voice notes and more.', 'onboarding_2.png'),
    ('Know When They’re Online', 'Get optional alerts when selected contacts come online or go offline.', 'profile_default.png'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Column(children: [
      Expanded(child: PageView.builder(
        controller: controller,
        itemCount: data.length,
        onPageChanged: (v) => setState(() => page = v),
        itemBuilder: (_, i) => Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Image.asset('assets/${data[i].$3}', height: 310, fit: BoxFit.contain),
            const SizedBox(height: 30),
            Text(data[i].$1, textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            Text(data[i].$2, textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, height: 1.5, color: Colors.grey.shade600)),
          ]),
        ),
      )),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(
        data.length, (i) => AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: page == i ? 26 : 8, height: 8,
          decoration: BoxDecoration(
            color: page == i ? const Color(0xFF0BAA72) : Colors.grey.shade300,
            borderRadius: BorderRadius.circular(20),
          ),
        ),
      )),
      Padding(padding: const EdgeInsets.fromLTRB(24, 22, 24, 18), child: SizedBox(
        width: double.infinity, height: 54,
        child: FilledButton(
          onPressed: () {
            if (page < data.length - 1) {
              controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
            } else {
              Navigator.pushReplacementNamed(context, '/login');
            }
          },
          child: Text(page == data.length - 1 ? 'Get Started' : 'Continue'),
        ),
      )),
    ])),
  );
}
