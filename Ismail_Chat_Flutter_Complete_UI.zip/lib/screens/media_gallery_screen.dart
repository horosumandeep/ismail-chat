
import 'package:flutter/material.dart';

class MediaGalleryScreen extends StatelessWidget {
  const MediaGalleryScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: const BackButton(), title: const Text('Media, links and docs', style: TextStyle(fontWeight: FontWeight.w800))),
    body: DefaultTabController(
      length: 3,
      child: Column(children: [
        const TabBar(tabs: [Tab(text: 'Media'), Tab(text: 'Links'), Tab(text: 'Docs')]),
        Expanded(child: TabBarView(children: [
          GridView.count(crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2, children: [
            'profile_default.png','onboarding_1.png','onboarding_2.png','media_illustration.png','splash_illustration.png','call_illustration.png',
          ].map((x) => Image.asset('assets/$x', fit: BoxFit.cover)).toList()),
          const Center(child: Text('No shared links')),
          ListView(children: const [
            ListTile(leading: Icon(Icons.picture_as_pdf, color: Colors.red), title: Text('Trip Plan.pdf'), subtitle: Text('2.4 MB')),
            ListTile(leading: Icon(Icons.description, color: Colors.blue), title: Text('Notes.docx'), subtitle: Text('84 KB')),
          ]),
        ])),
      ]),
    ),
  );
}
