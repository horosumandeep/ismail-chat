
import 'package:flutter/material.dart';

class OtpScreen extends StatelessWidget {
  const OtpScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(),
    body: SafeArea(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Verify your number', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Text('We sent a 6-digit code to +91 98765 43210', style: TextStyle(color: Colors.grey.shade600)),
        const SizedBox(height: 30),
        Row(children: List.generate(6, (i) => Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: i == 5 ? 0 : 8),
            child: TextField(
              textAlign: TextAlign.center, keyboardType: TextInputType.number, maxLength: 1,
              decoration: const InputDecoration(counterText: '', border: OutlineInputBorder()),
            ),
          ),
        ))),
        const SizedBox(height: 20),
        Center(child: TextButton(onPressed: () {}, child: const Text('Resend code in 00:30'))),
        const Spacer(),
        SizedBox(width: double.infinity, height: 54, child: FilledButton(
          onPressed: () => Navigator.pushReplacementNamed(context, '/profile'),
          child: const Text('Verify'),
        )),
      ]),
    )),
  );
}
