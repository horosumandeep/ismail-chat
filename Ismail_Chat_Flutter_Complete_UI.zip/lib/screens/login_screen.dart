
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(24), children: [
      Image.asset('assets/app_logo.png', width: 78, height: 78),
      const SizedBox(height: 18),
      const Text('Welcome to Ismail', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Text('Enter your mobile number to continue.', style: TextStyle(color: Colors.grey.shade600)),
      const SizedBox(height: 30),
      TextField(
        controller: phone, keyboardType: TextInputType.phone,
        decoration: const InputDecoration(
          labelText: 'Phone number', prefixText: '+91  ', border: OutlineInputBorder(),
        ),
      ),
      const SizedBox(height: 16),
      SizedBox(height: 52, child: FilledButton(
        onPressed: () => Navigator.pushNamed(context, '/otp'),
        child: const Text('Continue'),
      )),
      const SizedBox(height: 18),
      Row(children: [Expanded(child: Divider(color: Colors.grey.shade300)), const Padding(
        padding: EdgeInsets.symmetric(horizontal: 12), child: Text('OR'),
      ), Expanded(child: Divider(color: Colors.grey.shade300))]),
      const SizedBox(height: 14),
      OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.g_mobiledata), label: const Text('Continue with Google')),
      OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.mail_outline), label: const Text('Continue with Email')),
      const SizedBox(height: 24),
      Text('By continuing, you agree to our Terms & Privacy Policy.',
        textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
    ])),
  );
}
