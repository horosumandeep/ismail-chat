# Ismail Chat — Flutter UI

A complete WhatsApp-inspired Android UI starter built with Flutter and local PNG assets.

## Run
1. Install Flutter.
2. Extract this project.
3. Run `flutter pub get`.
4. Run `flutter run` on an Android device/emulator.

This build is UI-only. Authentication, realtime chat, FCM push notifications, Supabase backend, media uploads and calls can be connected next.

## Assets
All PNGs are in `assets/` and declared in `pubspec.yaml`.
